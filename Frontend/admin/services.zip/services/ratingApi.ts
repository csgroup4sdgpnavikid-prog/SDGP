// services/ratingApi.ts - API calls to the main NaviKid backend for driver ratings
//
// Update API_BASE_URL to match your machine's local IP when testing on a physical device.
// Run `ipconfig` (Windows) or `ifconfig` (Mac/Linux) and use the IPv4 address.
// Example: "http://192.168.1.5:3000"

import { Driver, Rating } from "../types";

const API_BASE_URL = __DEV__
  ? "http://172.17.144.1:3000"
  : "https://your-production-api.com"; // Replace with production URL

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `HTTP ${response.status}`);
  }
  return response.json();
}

/** Fetch all drivers available for rating */
export async function fetchDrivers(): Promise<Driver[]> {
  const data = await request<{ success: boolean; drivers: Driver[] }>("/drivers");
  return data.drivers;
}

/**
 * Submit a 3-criteria rating.
 * Requires the parent's UID (from Firebase Auth) and the driver's Firestore document ID.
 */
export async function submitRating(payload: {
  parentId: string;
  driverId: string;
  safety: number;
  punctuality: number;
  service: number;
  comment?: string;
}): Promise<{ success: boolean; message: string }> {
  return request("/ratings/submit", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

/**
 * Fetch all ratings with optional filters.
 * @param params.stars   Filter by overall star score (rounded, 1–5)
 * @param params.driverId Filter by driver document ID
 */
export async function fetchRatings(params?: {
  stars?: string;
  driverId?: string;
}): Promise<Rating[]> {
  const query = new URLSearchParams();
  if (params?.stars) query.set("stars", params.stars);
  if (params?.driverId) query.set("driverId", params.driverId);
  const qs = query.toString() ? `?${query.toString()}` : "";
  const data = await request<{ success: boolean; ratings: Rating[] }>(`/ratings${qs}`);
  return data.ratings;
}

/**
 * Check if a parent is still within the 90-day rating cooldown for a driver.
 */
export async function canRateDriver(parentId: string, driverId: string): Promise<{
  canRate: boolean;
  message: string;
  daysRemaining?: number;
}> {
  return request(`/ratings/can-rate?parentId=${parentId}&driverId=${driverId}`);
}
